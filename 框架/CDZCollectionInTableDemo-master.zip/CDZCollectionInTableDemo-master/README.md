# CDZCollectionInTableDemo
tableviewcell中内嵌collectionview自适应，图片分享，上传


[简书地址](http://www.jianshu.com/p/b907c198473d)
