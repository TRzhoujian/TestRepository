//
//  CDZCollectionViewItem.h
//  CDZCollectionInTableViewDemo
//
//  Created by Nemocdz on 2017/1/21.
//  Copyright © 2017年 Nemocdz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKIt.h>

@interface CDZCollectionViewItem : NSObject

@property (nonatomic,strong) UIImage *image;
@property (nonatomic,assign) BOOL delBtnHidden;

@end
