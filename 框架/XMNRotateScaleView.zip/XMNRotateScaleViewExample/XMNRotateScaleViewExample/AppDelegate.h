//
//  AppDelegate.h
//  XMNRotateScaleViewExample
//
//  Created by shscce on 15/11/30.
//  Copyright © 2015年 xmfraker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

