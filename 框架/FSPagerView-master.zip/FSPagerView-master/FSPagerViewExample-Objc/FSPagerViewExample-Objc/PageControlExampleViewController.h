//
//  PageControlExampleViewController.h
//  FSPagerViewExample-Objc
//
//  Created by Wenchao Ding on 20/01/2017.
//  Copyright © 2017 Wenchao Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageControlExampleViewController : UIViewController

@end
